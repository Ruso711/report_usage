<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Plugin strings are defined here.
 *
 * @package     report_usage
 * @category    string
 * @copyright   2019 Matus Rusnak <711.ruso@gmail.com>
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Usage';
$string['settings'] = 'Settings';
$string['lb_choose_category'] = 'Please, choose a category';
$string['lb_all_categories'] = 'All categories';
$string['lb_choose_course'] = 'Please, choose a course';
$string['lb_all_courses'] = 'All courses';
$string['lb_module_name'] = 'Module';
$string['lb_module_usage'] = 'Usage (%)';
$string['lb_module_amount'] = 'Amount';
$string['lb_course_name'] = 'Course name';
$string['lb_total_views'] = 'Total views';
$string['lb_student_views'] = 'Student views';
$string['lb_other_views'] = 'Others ';
$string['usage:view'] = 'View Usage report';
$string['lb_category_name'] = 'Category name';
$string['lb_course'] = 'Courses using the module: ';
$string['lb_chart_serie'] = 'Modules usage statistics';
$string['btn_refresh'] = 'Refresh';
$string['link_back'] = 'Back';
$string['link_summary'] = 'Course Usage';
$string['link_index'] = 'Catagory Usage';
$string['lb_categories_series_used_courses'] = 'Categories Statistics';