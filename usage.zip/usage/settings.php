<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Plugin administration pages are defined here.
 *
 * @package     report_usage
 * @category    admin
 * @copyright   2019 Matus Rusnak <711.ruso@gmail.com>
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();
if (has_capability('report/usage:view', context_system::instance())) {
    $ADMIN->add('root', new admin_category('report_usage',   get_string('pluginname', 'report_usage')));

    $ADMIN->add(
        'report_usage',
        new admin_externalpage(
            'usage_index',
            get_string('pluginname', 'report_usage'),
            new moodle_url('/report/usage/index.php'),
            'report/usage:view'
        )
    );


    $ADMIN->add(
        'report_usage',
        new admin_externalpage(
            'usage_admin',
            get_string('settings', 'report_usage'),
            new moodle_url('/report/usage/settings.php'),
            'report/usage:view'
        )
    );

    $ADMIN->add(
        'report_usage',
        new admin_externalpage(
            'usage_courseusage',
            get_string('pluginname', 'report_usage'),
            new moodle_url('/report/usage/courseusage.php'),
            'report/usage:view'
        )
    );

    $settings = null;
}