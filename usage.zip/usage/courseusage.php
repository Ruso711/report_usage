<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 *
 *
 * @package     report_usage
 * @copyright   2019 Matus Rusnak <711.ruso@gmail.com>
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require __DIR__ . '/../../config.php';
require_once $CFG->libdir . '/adminlib.php';

require_once __DIR__ . '/report_usage_courses_form.php';
require_once __DIR__ . '/constants.php';

admin_externalpage_setup('usage_courseusage', '', null, '', array('pagelayout' => 'report'));


$courses  = optional_param('course', REPORT_USAGE_ALL_COURSES, PARAM_INT);

echo $OUTPUT->header();
echo $OUTPUT->single_button(report_usage_url('index.php'),
    get_string('link_index', 'report_usage'));

$val = array();



$mform1 = new report_usage_courses_form();
$mform1->display();


if ($courses == REPORT_USAGE_ALL_COURSES) {
    $data_courses = $DB->get_records_sql(
        'SELECT M.name, M.id, COUNT(CM.id) AS amount FROM {modules} AS M INNER JOIN {course_modules} AS CM ON M.id = CM.module INNER JOIN {course} AS C ON C.id = CM.course WHERE C.visible = 1 GROUP BY M.name, M.id'
    );
    $total_courses = $DB->count_records_sql(
        'SELECT COUNT(CM.id) FROM {course} AS C INNER JOIN {course_modules} AS CM ON C.id = CM.course WHERE C.visible = 1'
    );
} else {
    $data_courses = $DB->get_records_sql(
        'SELECT M.name, M.id, COUNT(CM.id) AS amount FROM {modules} AS M INNER JOIN {course_modules} AS CM ON M.id = CM.module INNER JOIN {course} AS C ON C.id = CM.course WHERE C.visible = 1 AND C.id = :crs GROUP BY M.name, M.id',
        array("crs" => $courses)
    );
    $total_courses = $DB->count_records_sql(
        'SELECT COUNT(CM.id) FROM {course} AS C INNER JOIN {course_modules} AS CM ON C.id = CM.course WHERE C.visible = 1 AND C.id = :crs',
        array("crs" => $courses)
    );
}

if ($total_courses > 0) {

    $table_courses = new html_table();
    $table_courses->size = array( '60%', '20%', '20%');
    $table_courses->head = array(get_string('lb_module_name', 'report_usage'),
        get_string('lb_module_usage', 'report_usage'),
        get_string('lb_module_amount', 'report_usage'),
        "");

    $chart_labels = array();
    $chart_values = array();

    $index = 1;

    foreach ($data_courses as $item) {
        $row = array();

        $percent = number_format(($item->amount / $total_courses) * 100, 2);

        $chart_labels[] = $index . " - " . get_string('pluginname', 'mod_' . $item->name);
        $chart_values[] = $percent;

        $row[] = $index . " - " . get_string('pluginname', 'mod_' . $item->name);
        $row[] = $percent;

        $row[] = $item->amount;
        $index = $index + 1;

        $table_courses->data[] = $row;
    }



    if (class_exists('core\chart_bar')) {
        $chart = new core\chart_pie();
        $chart->set_doughnut(true);
        $serie = new core\chart_series(
            get_string('lb_module_usage', 'report_usage'), $chart_values
        );
        $chart->add_series($serie);
        $chart->set_labels($chart_labels);
        echo $OUTPUT->render_chart($chart, false);
    }




    echo html_writer::table($table_courses);
}

$course_views=$DB->get_records_sql(
    'SELECT lsl.courseid, c.fullname as coursename,
     COUNT(*) as total,
     SUM(CASE WHEN ra.roleid = 5 THEN 1 ELSE 0 END) as student,
     SUM(CASE WHEN ra.roleid <> 5 THEN 1 ELSE 0 END) as rest
FROM {logstore_standard_log} as lsl
JOIN {role_assignments} ra ON ra.userid = lsl.userid  
JOIN {course} AS c ON c.id = lsl.courseid
WHERE lsl.action = "viewed" AND lsl.target = "course"
GROUP BY lsl.courseid, c.fullname'
);
if ($course_views > 0) {

    $table_courses_details = new html_table();
    $table_courses_details->size = array( '55%', '15%', '15%', '15%');
    $table_courses_details->head = array(get_string('lb_course_name', 'report_usage'),
        get_string('lb_student_views', 'report_usage'),
        get_string('lb_other_views', 'report_usage'),
        get_string('lb_total_views', 'report_usage'),
        );

    foreach ($course_views as $item) {
        $row = array();



        $row[] = $item->coursename;
        $row[] = $item->student;

        $row[] = $item->rest;
        $row[] = $item->total;
        $table_courses_details->data[] = $row;
    }


    echo html_writer::table($table_courses_details);

}

echo $OUTPUT->footer();