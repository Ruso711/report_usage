<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 *
 *
 * @package     report_usage
 * @copyright   2019 Matus Rusnak <711.ruso@gmail.com>
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require __DIR__ . '/../../config.php';
require_once $CFG->libdir . '/adminlib.php';
require_once __DIR__ . '/report_usage_categories_form.php';
require_once __DIR__ . '/constants.php';


$context = context_system::instance();
require_capability('report/usage:view', $context);



admin_externalpage_setup('usage_index', '', null, '', array('pagelayout' => 'report'));

$categories = optional_param('category', REPORT_USAGE_ALL_CATAGORIES, PARAM_INT);


echo $OUTPUT->header();

echo $OUTPUT->single_button(report_usage_url('courseusage.php'),
    get_string('link_summary', 'report_usage'));


    $mform = new report_usage_categories_form();
$mform->display();






if ($categories == REPORT_USAGE_ALL_CATAGORIES) {
    $data = $DB->get_records_sql(
        'SELECT M.name, M.id, COUNT(CM.id) AS amount FROM {modules} AS M INNER JOIN {course_modules} AS CM ON M.id = CM.module INNER JOIN {course} AS C ON C.id = CM.course WHERE C.visible = 1 GROUP BY M.name, M.id'
    );
    $total = $DB->count_records_sql(
        'SELECT COUNT(CM.id) FROM {course} AS C INNER JOIN {course_modules} AS CM ON C.id = CM.course WHERE C.visible = 1'
    );
} else {  
    $data = $DB->get_records_sql(
        'SELECT M.name, M.id, COUNT(CM.id) AS amount FROM {modules} AS M INNER JOIN {course_modules} AS CM ON M.id = CM.module INNER JOIN {course} AS C ON C.id = CM.course WHERE C.visible = 1 AND C.category = :cat GROUP BY M.name, M.id',
        array("cat" => $categories)
    );
    $total = $DB->count_records_sql(
        'SELECT COUNT(CM.id) FROM {course} AS C INNER JOIN {course_modules} AS CM ON C.id = CM.course WHERE C.visible = 1 AND C.category = :cat',
        array("cat" => $categories)
    ); 
}

if ($total > 0) {

    $table = new html_table();
    $table->size = array( '60%', '20%', '20%');
    $table->head = array(get_string('lb_module_name', 'report_usage'),
        get_string('lb_module_usage', 'report_usage'),
        get_string('lb_module_amount', 'report_usage'),
        "");

    $chart_labels = array();
    $chart_values = array();

    $index = 1;

    foreach ($data as $item) {
        $row = array();

        $percent = number_format(($item->amount / $total) * 100, 2);

        $chart_labels[] = $index . " - " . get_string('pluginname', 'mod_' . $item->name);
        $chart_values[] = $percent;

        $row[] = $index . " - " . get_string('pluginname', 'mod_' . $item->name);
        $row[] = $percent;

        $row[] = $item->amount;
        $index = $index + 1;

        $table->data[] = $row;
    }

    if (class_exists('core\chart_bar')) {
        $chart = new core\chart_pie();

        $serie = new core\chart_series(
            get_string('lb_module_usage', 'report_usage'), $chart_values
        );
        $chart->add_series($serie);
        $chart->set_labels($chart_labels);
        echo $OUTPUT->render_chart($chart, false);
    }






    echo html_writer::table($table);
}
$cat_views=$DB->get_records_sql(
    'SELECT cc.id, cc.name as catname,
     COUNT(*) as total,
     SUM(CASE WHEN ra.roleid = 5 THEN 1 ELSE 0 END) as student,
     SUM(CASE WHEN ra.roleid <> 5 THEN 1 ELSE 0 END) as rest
FROM {logstore_standard_log} as lsl
JOIN {role_assignments} ra ON ra.userid = lsl.userid  
JOIN {course} AS c ON c.id = lsl.courseid
JOIN {course_categories} as cc on cc.id = c.category
WHERE lsl.action = "viewed" AND lsl.target = "course"
GROUP BY cc.id, cc.name'
);
if ($cat_views > 0) {

    $chart_labels1 = array();
    $chart_total = array();
    $chart_student = array();
    $chart_rest = array();
    $table_cat_details = new html_table();
    $table_cat_details->size = array( '55%', '15%', '15%', '15%');
    $table_cat_details->head = array(get_string('lb_category_name', 'report_usage'),
        get_string('lb_student_views', 'report_usage'),
        get_string('lb_other_views', 'report_usage'),
        get_string('lb_total_views', 'report_usage'),
    );

    foreach ($cat_views as $item) {
        $row = array();



        $row[] = $item->catname;
        $row[] = $item->student;

        $row[] = $item->rest;
        $row[] = $item->total;
        $table_cat_details->data[] = $row;
    }


    echo html_writer::table($table_cat_details);

}
echo $OUTPUT->footer();